export const environment = {
  production: true,
  apiURL: 'http://localhost:3000',
};
